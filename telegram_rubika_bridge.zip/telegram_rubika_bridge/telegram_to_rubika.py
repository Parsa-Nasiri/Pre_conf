#!/usr/bin/env python3
"""
Telegram channel watcher -> Rubika forwarder

Uses:
- Telethon with a Telegram user session to read public Telegram channels.
- Rubika Bot API to send notifications to your Rubika chat.

Required secrets / vars:
  TG_API_ID
  TG_API_HASH
  TG_SESSION_STRING
  RUBIKA_BOT_TOKEN
  RUBIKA_CHAT_ID
  TG_CHANNELS
Optional:
  STATE_FILE        default: state/last_seen.json
  MAX_MESSAGES_PER_CHANNEL default: 100
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import requests
from telethon import TelegramClient
from telethon.errors import FloodWaitError
from telethon.sessions import StringSession


RUBIKA_API_BASE = "https://botapi.rubika.ir/v3"
DEFAULT_STATE_FILE = "state/last_seen.json"
DEFAULT_MAX_MESSAGES = 100


@dataclass(frozen=True)
class ChannelRef:
    raw: str
    username: str


def env(name: str, default: str | None = None) -> str:
    value = os.getenv(name, default)
    if value is None or value.strip() == "":
        raise SystemExit(f"Missing required environment variable: {name}")
    return value.strip()


def parse_channels(raw: str) -> List[ChannelRef]:
    items = [part.strip() for part in re.split(r"[,\n]+", raw) if part.strip()]
    out: List[ChannelRef] = []

    for item in items:
        username = item
        username = username.replace("https://t.me/", "").replace("http://t.me/", "")
        username = username.replace("https://telegram.me/", "").replace("http://telegram.me/", "")
        username = username.lstrip("@").split("?")[0].strip("/")
        if not username:
            continue
        out.append(ChannelRef(raw=item, username=username))

    if not out:
        raise SystemExit("TG_CHANNELS is empty after parsing.")
    return out


def load_state(path: Path) -> Dict[str, int]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {}
        result: Dict[str, int] = {}
        for key, value in data.items():
            try:
                result[str(key)] = int(value)
            except Exception:
                continue
        return result
    except Exception:
        return {}


def save_state(path: Path, state: Dict[str, int]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def rubika_send(token: str, chat_id: str, text: str) -> None:
    url = f"{RUBIKA_API_BASE}/{token}/sendMessage"
    payload = {"chat_id": chat_id, "text": text}
    r = requests.post(url, json=payload, timeout=30)
    r.raise_for_status()


def format_message(channel: str, message) -> str:
    title = getattr(message, "message", None) or getattr(message, "text", None) or ""
    title = str(title).strip()

    if not title and getattr(message, "media", None):
        title = "[media post]"

    link = f"https://t.me/{channel}/{message.id}"
    header = f"📣 {channel}\n🔗 {link}"

    if title:
        return f"{header}\n\n{title}"
    return header


async def collect_new_messages(client: TelegramClient, channel: ChannelRef, last_seen: int, limit: int) -> List[object]:
    entity = await client.get_entity(channel.username)
    messages = []
    async for msg in client.iter_messages(entity, limit=limit):
        if msg and getattr(msg, "id", 0) > last_seen:
            messages.append(msg)

    messages.sort(key=lambda m: m.id)
    return messages


async def main_async() -> None:
    api_id = int(env("TG_API_ID"))
    api_hash = env("TG_API_HASH")
    session_string = env("TG_SESSION_STRING")
    rubika_token = env("RUBIKA_BOT_TOKEN")
    rubika_chat_id = env("RUBIKA_CHAT_ID")
    channels = parse_channels(env("TG_CHANNELS"))
    state_file = Path(os.getenv("STATE_FILE", DEFAULT_STATE_FILE))
    max_messages = int(os.getenv("MAX_MESSAGES_PER_CHANNEL", str(DEFAULT_MAX_MESSAGES)))

    state = load_state(state_file)

    client = TelegramClient(StringSession(session_string), api_id, api_hash)
    await client.start()

    try:
        changed = False

        for channel in channels:
            last_seen = state.get(channel.username, 0)

            try:
                new_messages = await collect_new_messages(client, channel, last_seen, max_messages)
            except FloodWaitError as exc:
                raise SystemExit(f"Telegram asked to wait {exc.seconds} seconds. Reduce frequency or channels.") from exc

            if not new_messages:
                continue

            for msg in new_messages:
                text = format_message(channel.username, msg)
                rubika_send(rubika_token, rubika_chat_id, text)

            newest_id = max(msg.id for msg in new_messages)
            if newest_id > last_seen:
                state[channel.username] = newest_id
                changed = True

        if changed:
            save_state(state_file, state)
    finally:
        await client.disconnect()


if __name__ == "__main__":
    import asyncio
    asyncio.run(main_async())
