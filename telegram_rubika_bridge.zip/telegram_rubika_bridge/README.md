# Telegram to Rubika bridge

This project watches public Telegram channels with a Telegram user session, then forwards new posts to a Rubika chat.

## Why this setup

Telegram `api_id` and `api_hash` come from `my.telegram.org`. Telethon uses them together with a session string for user authorization. Rubika bots send messages through the Bot API endpoint `https://botapi.rubika.ir/v3/{token}/sendMessage`. GitHub Actions scheduled workflows run on the default branch, at the fastest every 5 minutes, and GitHub-hosted jobs stop after 6 hours. citeturn847942view0turn885763view2turn379588view0turn885763view3turn885763view4

## Files

- `telegram_to_rubika.py`
- `requirements.txt`
- `.github/workflows/telegram-to-rubika.yml`

## Secrets and variables

Create these GitHub Secrets:

- `TG_API_ID`
- `TG_API_HASH`
- `TG_SESSION_STRING`
- `RUBIKA_BOT_TOKEN`
- `RUBIKA_CHAT_ID`

Create this GitHub Actions variable:

- `TG_CHANNELS`

Optional:

- `STATE_FILE`, defaults to `state/last_seen.json`
- `MAX_MESSAGES_PER_CHANNEL`, defaults to `100`

## Channel list

Put your channels in `TG_CHANNELS` as a comma-separated list, or one per line:

```text
https://t.me/ConfigX2ray
https://t.me/SPIDER_CONFIG
https://t.me/appxa
https://t.me/saministamm
https://t.me/proxy_kafee
https://t.me/MatinSenPaii
https://t.me/i10VPN
```

## One-time Telegram session setup

Run a local helper once to create `TG_SESSION_STRING`, then store it as a GitHub secret. Keep the string private.

## Rubika destination

Set `RUBIKA_CHAT_ID` to the chat ID where you want the alerts.

## Notes

- The workflow keeps a small `state/last_seen.json` file in the repo so it only forwards new posts.
- The workflow commits that state file back to the repository.
- The schedule uses `*/5 * * * *`, since GitHub Actions supports a minimum interval of 5 minutes for scheduled workflows. citeturn885763view3
