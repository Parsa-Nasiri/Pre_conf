#!/usr/bin/env python3
"""
Run this locally once to print a Telegram StringSession.

Usage:
  pip install telethon
  python generate_session.py

Then follow the login prompts and copy the printed session string into TG_SESSION_STRING.
"""

from telethon import TelegramClient
from telethon.sessions import StringSession

api_id = int(input("TG_API_ID: ").strip())
api_hash = input("TG_API_HASH: ").strip()

with TelegramClient(StringSession(), api_id, api_hash) as client:
    print("\nTG_SESSION_STRING:\n")
    print(client.session.save())
